package com.gl.dao;

import java.util.List;

import com.gl.model.Supplier;



public interface SupplierDao {

	public Supplier getSupplierByIdDao(int id);
	public List <Supplier> getAllSuppliersDao();
	public void saveSupplierDao(Supplier supplier);
	public void deleteSupplierDao(int id);

}
