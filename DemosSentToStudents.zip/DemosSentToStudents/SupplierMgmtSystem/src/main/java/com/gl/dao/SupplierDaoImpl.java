package com.gl.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.gl.model.Supplier;

@Repository
@EnableTransactionManagement
public class SupplierDaoImpl implements SupplierDao{

	SessionFactory sessionFactory;
	Session session;
	
	public SupplierDaoImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory = sessionFactory;
		this.session = sessionFactory.openSession();
	}
	
	@Override
	@Transactional
	public Supplier getSupplierByIdDao(int id) {
		// TODO Auto-generated method stub
		Supplier supplier = new Supplier();
		Transaction tx = session.beginTransaction();
		supplier = session.get(Supplier.class, id);
		tx.commit();
		return supplier;
	}

	@Override
	public List<Supplier> getAllSuppliersDao() {
		// TODO Auto-generated method stub
		Transaction tx = session.beginTransaction();
		List <Supplier> suppliers  = session.createQuery("from Supplier").list();
		tx.commit();
		return suppliers;
	}

	@Override
	public void saveSupplierDao(Supplier supplier) {
		// TODO Auto-generated method stub
		Transaction tx = session.beginTransaction();
		session.save(supplier);
		tx.commit();
		
	}

	@Override
	public void deleteSupplierDao(int id) {
		// TODO Auto-generated method stub
		Transaction tx = session.beginTransaction();
		Supplier supplier = session.get(Supplier.class, id);
		session.delete(supplier);
		tx.commit();
		
	}

}
