package com.gl.service;

import java.util.List;

import com.gl.model.Supplier;



public interface SupplierService {
	
	public Supplier getSupplierByIdSvc(int id);
	public List <Supplier> getAllSuppliersSvc();
	public void saveSupplierSvc(Supplier supplier);
	public void deleteSupplierSvc(int id);

}
