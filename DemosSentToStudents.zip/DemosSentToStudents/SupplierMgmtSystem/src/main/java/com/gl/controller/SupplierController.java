package com.gl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gl.model.Supplier;
import com.gl.service.SupplierService;





@Controller
@RequestMapping("/suppliers")
public class SupplierController {
	
	@Autowired
	SupplierService supplierService;
	
	@RequestMapping("/list")
	public String getSuppliers(Model model)
	{
		List <Supplier> suppliers = supplierService.getAllSuppliersSvc();
		model.addAttribute("suppliers", suppliers);
		return "supplierlist";
	}
	
	@RequestMapping("/add")
	public String showAddSupplierForm(Model model)
	{
		Supplier supplier = new Supplier();
		model.addAttribute("supplier", supplier); 
		return "supplierform";
	}
	// http://localhost:8080/glcamavenjsphiber/suppliers/update?empId=${supplier.id}
	@RequestMapping("/update")
	public String showFormForUpdate(@RequestParam("supId") int sid,Model model)
	{
		Supplier supplier1 = supplierService.getSupplierByIdSvc(sid);
		model.addAttribute("supplier", supplier1);
		return "supplierform";
	}
	
	@RequestMapping("/save")
	public String saveSupplier(@RequestParam("supId") int sId,
								@RequestParam("supName") String sName,
								@RequestParam("supAddr") String sAddr,
								@RequestParam("supPhone") String sPhon,
								@RequestParam("supeMail") String supeMail,
								@RequestParam("prodCat") String prodCat,
								Model model)
	{
		Supplier supplier = new Supplier();
		if(sId != 0)
		{
			supplier = supplierService.getSupplierByIdSvc(sId);
			supplier.setSupplierName(sName);
			supplier.setSupplierAddress(sAddr);
			supplier.setSupplierPhone(sPhon);
			supplier.setSuppliereMail(supeMail);
			supplier.setProductCategories(prodCat);
		}
		else
		{
			supplier = new Supplier(sName,sAddr,sPhon,supeMail,prodCat);
		}
		supplierService.saveSupplierSvc(supplier);
		return "redirect:/suppliers/list";
	}
	
	@RequestMapping("/delete")
	public String deleteSupplier(@RequestParam("supId") int sid)
	{
		supplierService.deleteSupplierSvc(sid);
		return "redirect:/suppliers/list";
	}

}
