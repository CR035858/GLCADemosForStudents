package com.gl.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.gl.dao.SupplierDao;
import com.gl.model.Supplier;



@Service
@EnableTransactionManagement
public class SupplierServiceImpl implements SupplierService {

	@Autowired
	SupplierDao supplierDao;
	
	@Override
	public Supplier getSupplierByIdSvc(int id) {
		// TODO Auto-generated method stub
		return supplierDao.getSupplierByIdDao(id);
	}

	@Override
	public List<Supplier> getAllSuppliersSvc() {
		// TODO Auto-generated method stub
		return supplierDao.getAllSuppliersDao();
	}

	@Override
	public void saveSupplierSvc(Supplier supplier) {
		// TODO Auto-generated method stub
		supplierDao.saveSupplierDao(supplier);
	}

	@Override
	public void deleteSupplierSvc(int id) {
		// TODO Auto-generated method stub
		supplierDao.deleteSupplierDao(id);
	}

}
